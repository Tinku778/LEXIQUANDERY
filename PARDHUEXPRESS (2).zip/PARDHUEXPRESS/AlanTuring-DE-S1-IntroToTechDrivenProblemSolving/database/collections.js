module.exports = {
    USERS: 'users',
    LEXIQUANDARYTECHKY: 'lexiquandarytechky'
}