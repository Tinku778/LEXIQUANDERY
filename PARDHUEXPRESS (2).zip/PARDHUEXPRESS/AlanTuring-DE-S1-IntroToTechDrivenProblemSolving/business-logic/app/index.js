const app = module.exports;

app.create = require('./create');
app.read = require('./read');
app.update = require('./update');