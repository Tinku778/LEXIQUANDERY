const api = module.exports;

api.authentication = require('./authentication');
api.user = require('./user');
api.app = require('./app');